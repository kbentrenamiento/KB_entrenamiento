// =============================================
// KB ENTRENAMIENTO — Supabase Config
// =============================================
// INSTRUCCIONES:
// 1. Creá una cuenta gratis en https://supabase.com
// 2. Creá un nuevo proyecto
// 3. Andá a Settings > API
// 4. Copiá tu Project URL y anon public key
// 5. Reemplazá los valores de abajo con los tuyos

const SUPABASE_URL = 'TU_SUPABASE_URL_AQUI';
const SUPABASE_KEY = 'TU_SUPABASE_ANON_KEY_AQUI';

// Inicializar cliente Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// =============================================
// UTILIDADES GLOBALES
// =============================================

/** Mostrar toast notification */
function showToast(msg, type = 'success') {
  const container = document.getElementById('toast-container') || (() => {
    const c = document.createElement('div');
    c.id = 'toast-container';
    document.body.appendChild(c);
    return c;
  })();
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${icons[type] || '•'}</span><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

/** Obtener sesión actual */
async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

/** Obtener perfil completo del usuario */
async function getUserProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  if (error) console.error('Error fetching profile:', error);
  return data;
}

/** Verificar si el usuario es admin */
async function isAdmin() {
  const user = await getCurrentUser();
  if (!user) return false;
  const profile = await getUserProfile(user.id);
  return profile?.is_admin === true;
}

/** Formatear fecha a formato legible */
function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

/** Calcular días hasta vencimiento */
function daysUntil(dateStr) {
  if (!dateStr) return null;
  const now = new Date();
  const target = new Date(dateStr);
  now.setHours(0,0,0,0);
  target.setHours(0,0,0,0);
  return Math.round((target - now) / (1000 * 60 * 60 * 24));
}

/** Obtener clase de estado para cuota/apto */
function getStatusInfo(daysLeft) {
  if (daysLeft === null) return { label: 'Sin datos', cls: 'badge-red', alert: 'danger' };
  if (daysLeft < 0)  return { label: 'Vencido',    cls: 'badge-red',    alert: 'danger'  };
  if (daysLeft <= 15) return { label: `Vence en ${daysLeft}d`, cls: 'badge-orange', alert: 'warning' };
  return { label: 'Al día', cls: 'badge-green', alert: 'success' };
}

/** Redirigir si no hay sesión */
async function requireAuth(redirectTo = 'login.html') {
  const user = await getCurrentUser();
  if (!user) { window.location.href = redirectTo; return null; }
  return user;
}

/** Redirigir si no es admin */
async function requireAdmin() {
  const user = await requireAuth();
  if (!user) return null;
  const admin = await isAdmin();
  if (!admin) { showToast('Acceso denegado', 'error'); setTimeout(() => window.location.href = 'index.html', 1500); return null; }
  return user;
}

/** Nombres de días */
const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

/** Colores por tipo de clase */
const CLASS_COLORS = {
  'Funcional':        'funcional',
  'Yoga / Pilates':   'yoga',
  'Running':          'running',
  'Funcional Kids':   'kids',
  'Zumba':            'zumba',
  'Tercera Edad':     'tercera'
};

function getClassPill(name) {
  const cls = CLASS_COLORS[name] || 'funcional';
  return `<span class="class-pill cp-${cls}">${name}</span>`;
}
